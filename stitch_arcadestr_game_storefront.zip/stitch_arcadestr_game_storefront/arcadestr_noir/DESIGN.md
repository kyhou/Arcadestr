# Design System Specification: The Ethereal Storefront

## 1. Overview & Creative North Star
**Creative North Star: "The Neon Curator"**
This design system moves away from the utilitarian, boxy layouts of traditional gaming platforms in favor of an editorial, futuristic experience. It treats the digital storefront not as a database of products, but as a high-end gallery of digital experiences. 

By leveraging **intentional asymmetry**, **glassmorphism**, and **tonal layering**, we break the "template" look. We favor breathing room and cinematic scale over information density. The goal is a "decentralized chic" aesthetic—where the Nostr protocol's social layer feels natively woven into the commerce layer, rather than an afterthought.

---

## 2. Colors & Surface Philosophy
The palette is rooted in the depth of space, using high-saturation accents to guide the eye through a decentralized landscape.

### Surface Hierarchy & Nesting
Forget "flat." The UI is a series of stacked, semi-translucent sheets. 
- **The "No-Line" Rule:** 1px solid borders are strictly prohibited for sectioning. Use background shifts to define areas. A `surface-container-low` card sitting on a `background` provides all the edge definition required.
- **Surface Tiers:**
    - `background` (#0a0e14): The base vacuum of space.
    - `surface-container-low` (#0f141a): Sub-navigation or subtle groupings.
    - `surface-container-high` (#1b2028): Interactive game cards and social "Nostr" notes.
    - `surface-bright` (#262c36): High-impact modals or active states.

### The "Glass & Gradient" Rule
To achieve the "Premium Gaming" feel, primary actions and hero elements must use **Signature Textures**. 
- **CTAs:** Never use a flat color. Use a linear gradient from `primary` (#b6a0ff) to `primary_dim` (#7e51ff).
- **Glassmorphism:** For floating social feeds or hover overlays, use `surface_container_high` at 60% opacity with a `24px` backdrop-blur.

---

## 3. Typography
We utilize a dual-typeface system to balance technical precision with cinematic impact.

| Level | Font Family | Token | Purpose |
| :--- | :--- | :--- | :--- |
| **Display** | Space Grotesk | `display-lg` | Hero game titles & promotional headlines. |
| **Headline** | Space Grotesk | `headline-md` | Section headers (e.g., "Trending Notes"). |
| **Title** | Inter | `title-lg` | Game card titles and navigational links. |
| **Body** | Inter | `body-md` | Game descriptions and social feed content. |
| **Label** | Inter | `label-sm` | Metadata, tags, and micro-copy. |

**Editorial Note:** Use `display-lg` with a negative letter-spacing of `-0.02em` to create a more "bespoke" editorial feel for game launches.

---

## 4. Elevation & Depth
Depth is a functional tool, not a stylistic choice. We use **Tonal Layering** to convey hierarchy.

- **The Layering Principle:** Instead of shadows, move from `surface_container_lowest` for the background up to `surface_container_highest` for the most prominent foreground elements.
- **Ambient Shadows:** For floating elements like tooltips or hover-state cards, use a diffused shadow: `0px 20px 40px rgba(0, 0, 0, 0.4)`. The shadow should feel like a soft glow of "absence" rather than a hard drop-shadow.
- **The "Ghost Border" Fallback:** If accessibility requires a border, use `outline_variant` (#44484f) at **15% opacity**. This creates a whisper of a boundary that doesn't break the visual flow.

---

## 5. Components

### Buttons (The "Pulse" of the Store)
- **Primary:** Gradient (`primary` to `primary_dim`). Roundedness: `md` (0.75rem). Use `on_primary` for text.
- **Secondary (Buy/Play):** `secondary` (#00d2fd) flat fill. These are high-visibility "Action" points.
- **Tertiary:** Ghost style. No background, only `on_surface` text. On hover, apply a `surface_variant` background at 30% opacity.

### Game Cards
- **Construction:** No dividers. Use `xl` (1.5rem) rounded corners.
- **Hover State:** Upon hover, the card should scale (1.02x) and transition from `surface_container_high` to `surface_bright`. 
- **Metadata:** Use `label-md` for "Nostr" social activity counts (e.g., "⚡ 4.2k Zaps").

### Social Feed Elements (Nostr Notes)
- Integrated as "Glass" overlays on game pages.
- Use `surface_container_low` with a 10% opacity `outline_variant` ghost border. 
- Profile avatars use `full` (circular) rounding to contrast against the `md` rounded corners of the game UI.

### Input Fields
- **Search:** `surface_container_highest` background, no border. Use `on_surface_variant` for placeholder text.
- **Focus State:** A subtle 2px glow using `secondary_dim` with a 40% opacity blur.

---

## 6. Do's and Don'ts

### Do
- **Do** use asymmetrical spacing. A hero banner can be 70% width, leaving 30% for a "Live Feed" of Nostr notes to create a dynamic, non-grid feel.
- **Do** lean into the `tertiary` (#ff96bb) color for "Zaps" or social highlights to provide a warm counterpoint to the cool blue/purple base.
- **Do** ensure all images/banners have a subtle bottom-heavy black gradient to ensure `headline` text is legible over imagery.

### Don't
- **Don't** use 100% white (#ffffff). Always use `on_surface` (#f1f3fc) to maintain the premium, low-strain dark theme.
- **Don't** use dividers or lines to separate list items. Use vertical white space (`1.5rem` to `2rem`) to denote separation.
- **Don't** use standard "Rounded" (4px) corners. Stick to the Roundedness Scale: `md` for buttons and `xl` for large containers to maintain the "Soft Future" aesthetic.

---

## 7. Roundedness Scale
- **none:** 0px (Special utility only)
- **sm:** 0.25rem (Small tags/labels)
- **DEFAULT:** 0.5rem (Standard small components)
- **md:** 0.75rem (Buttons, Input fields)
- **lg:** 1rem (Small cards, Modals)
- **xl:** 1.5rem (Game cards, Hero banners)
- **full:** 9999px (Avatars, Pill buttons)