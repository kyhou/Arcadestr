---
name: arcadestr-design
description: Use when creating or modifying any Arcadestr UI - new screens, pages, cards, modals, empty states, badges, buttons, or forms. Provides the Signal Terminal design language (tokens, component recipes, semantic layering rules) so new items match the existing storefront and publisher console.
---

# Arcadestr design language ("Signal Terminal")

Dark, monospace, terminal-flavoured marketplace UI. Every new item MUST follow the tokens
and recipes below rather than inventing its own styling.

## Non-negotiables

1. **Monospace everywhere.** `ui-monospace,monospace` is the only family. No Inter/Roboto.
2. **Inline styles only.** No CSS classes, no stylesheet, no design-token JS file.
   Repeat literal values. Only `@font-face`, `@keyframes` and body resets may live in `<style>`.
3. **Page shell is `max-width:1440px;margin:0 auto`** — applied to BOTH the sticky top bar's
   inner row and the main content column, so edges align when the window is maximized.
   Never let one stretch full-bleed while the other is capped.
4. **Three semantic layers stay visually distinct** (see "Semantic layering").
5. **No invented colors.** Pick from the palette below.

## Palette

| Role | Value |
|---|---|
| Page background | `#0b0b0d` |
| Bar / raised surface | `#0d0d10` |
| Card surface | `#121215` |
| Inset / field surface | `#141417` (art wells `#141419`) |
| Hairline border | `oklch(0.32 0.01 60)` / `rgba(255,255,255,.1)` |
| Section divider | `oklch(0.4 0.03 60 / .3)` |
| Primary text | `#fff` |
| Body text | `oklch(0.68 0.01 60)` |
| Secondary text | `oklch(0.6 0.01 60)` |
| Muted / placeholder | `oklch(0.45–0.55 0.01 60)` |
| **Amber** (brand, section headers, primary CTA) | `oklch(0.78 0.16 60)` / header text `oklch(0.8 0.16 60)` |
| **Cyan** (network, links, secondary CTA, verified) | `oklch(0.8 0.14 195)`, border `oklch(0.45 0.13 195)` |
| **Blue** (tags, access chips, details buttons) | `oklch(0.78 0.13 210)`, border `oklch(0.5 0.13 210)` |
| **Red** (destructive, errors, expiry) | `oklch(0.65 0.18 25)` |
| Avatar gradient | `linear-gradient(135deg,oklch(0.55 0.1 320),oklch(0.4 0.1 260))` |

Radii: `3px` chips/small, `4px` buttons/fields, `5px` primary buttons, `6–8px` cards & panels.

## Type scale

| Use | Style |
|---|---|
| Wordmark | `800 19px/1`, `letter-spacing:2px`, `#fff` |
| Hero title | `800 32px/1.08`, `letter-spacing:.5px` |
| Page title | `800 22px` |
| Card title | `800 16–17px/1.15` |
| Section header (amber, kicker) | `800 11–12px`, `letter-spacing:1.5px`, uppercase |
| Button label | `800 13px` (`800 11px` for in-card actions) |
| Body | `400 12.5–13px/1.6–1.7` |
| Meta / caption | `600 10.5–11px` |

## Component recipes

**Section header** — amber uppercase kicker + dashed rule filling the row:
```html
<div style="display:flex;align-items:center;gap:10px;margin-bottom:18px">
  <span style="font:800 12px ui-monospace,monospace;letter-spacing:1.5px;color:oklch(0.8 0.16 60)">◆ SECTION NAME</span>
  <span style="flex:1;height:1px;background:repeating-linear-gradient(90deg,oklch(0.4 0.03 60 / .6) 0 4px,transparent 4px 8px)"></span>
</div>
```

**Card** — notched corners are the signature; never a plain rounded rect for content cards:
```html
<div style="clip-path:polygon(0 0,calc(100% - 12px) 0,100% 12px,100% 100%,12px 100%,0 calc(100% - 12px));border:1px solid oklch(0.3 0.01 60);background:#121215">
```
Grids are `repeat(4,1fr)` with `gap:18px` inside `padding:26px 28px`.

**Buttons**
- Primary: `padding:11px 20px;background:oklch(0.78 0.16 60);color:#0b0b0d;font:800 13px …;border-radius:5px`
- Secondary: `border:1px solid oklch(0.5 0.13 210);color:oklch(0.8 0.13 210)` on transparent
- Tertiary: `border:1px solid rgba(255,255,255,.22);color:oklch(0.65 0.01 60)`
- Destructive: text/border in `oklch(0.65 0.18 25)`
- Trailing `>` on navigational labels (`DETAILS >`, `PUBLISH A GAME >`).

**Chips** — `padding:4px 11px;border:1px solid <accent>;background:<accent>/.14;font:700 11px;border-radius:4px`.

**Missing imagery** — never a blank box; use the diagonal hatch placeholder:
`background:repeating-linear-gradient(135deg,#191919 0 10px,#141414 10px 20px)` with a
`600 10.5px` muted caption (`ARTWORK PENDING`, `KEY ART — SUPPLIED BY PUBLISHER`).

**Empty state** — centered column, `padding:110px 28px;min-height:420px`: 64px hatched circle
icon, `800 20px` headline in sentence case, `400 12.5px/1.6` muted explanation capped at
`max-width:380px`, then one secondary + one tertiary CTA in a `gap:12px` row. Explanation says
what will make content appear, not just that it is empty. Every list/grid screen needs one.

## Semantic layering (critical)

Three separate ideas must never be collapsed into one badge:

1. **Acquisition method** — how you get it: Paid / Public access / Timed access / Claim & keep.
   Rendered as the colored badge chip.
2. **Access state** — what you hold now: owned, expiring, not held. Rendered as plain colored
   text next to the badge (red `oklch(0.65 0.18 25)` only when a real deadline exists).
3. **Local install state** — the contextual action button: `PLAY` / `INSTALL` / `UPDATE` /
   `BUY` / `CLAIM`. Always the last element in the card body.

Only show an expiry badge where there is a genuine deadline. Do not claim ownership the user
does not have; "PERMANENT OWNERSHIP" applies only to claim-and-keep or purchased titles.

## Copy rules

- UI labels, kickers and buttons: UPPERCASE monospace.
- Headlines and explanatory prose: sentence case, plain language, no marketing fluff.
- Terminal ornaments (`[ FEATURED TITLE ]`, `◆`, `<`/`>`, `((•))`) are used sparingly as
  section markers — never inside body prose.
- No emoji except the established set: `⚡` lightning, `🔒` ownership, `((•))` nostr.

## Layout / responsiveness

- Content column capped at 1440px and centered; interior padding `26px 28px`.
- Split hero is `grid-template-columns:38% 62%`; detail pages `1fr 380px`.
- Grids must use `minmax(0,1fr)` tracks when content can overflow.
- Sticky top bar: `height:64px`, `z-index:50`, bottom hairline, inner row capped at 1440px.
- Never fixed heights on text containers; never `nowrap` on labels that can grow.

## Checklist before finishing a new item

- [ ] Monospace, inline styles, palette colors only
- [ ] Capped + centered within the 1440px column; verified at maximized width
- [ ] Notched card shape used for content cards
- [ ] Acquisition / access / install kept as three separate signals
- [ ] Empty, loading-less fallback and missing-image states designed
- [ ] Contrast ≥ 4.5:1 for body text on its surface
