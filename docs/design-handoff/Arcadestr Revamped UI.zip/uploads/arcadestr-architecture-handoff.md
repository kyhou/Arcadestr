# Arcadestr — Architecture Handoff

## What it is
Arcadestr is a desktop marketplace application built on the Nostr protocol. It lets users list, discover, and purchase items (games and related digital/physical goods) peer-to-peer, with payment and order-status flows layered on top of Nostr events rather than a central server.

## Core stack
- **Tauri v2** — desktop shell (Rust backend + native webview)
- **Leptos 0.8** — Rust-based reactive frontend framework, compiled to the webview
- **nostr-sdk 0.44** — Nostr protocol client library (event creation, relay comms, subscriptions)
- **SQLite** — local persistence/cache layer

## Workspace layout
Multi-crate Rust workspace:
- `core/` — protocol logic, Nostr event types, marketplace domain model (`core/src/nostr.rs`)
- `app/` — application-level models and business logic (`app/src/models.rs`)
- `desktop/` — Tauri entry point, native integration, dev tooling (e.g. `tauri-plugin-mcp-bridge`, gated behind `#[cfg(debug_assertions)]`)

## Domain model — listings
There are currently **two `GameListing` structs**, one in `core/src/nostr.rs` (protocol-facing, maps to Nostr event tags/content) and one in `app/src/models.rs` (application-facing). Anyone picking this up should treat that split as intentional but worth watching — tag-name alignment between the two has already caused bugs during the NIP-99 migration and needs to stay in sync whenever either struct changes.

Listings are published/discovered as **NIP-99 classified listings (kind 30402)**. The app previously used NIP-15 and has been migrated off it — NIP-15 references or assumptions should not reappear.

## Protocol layer — Nostr specifics
- **Listing discovery**: kind 30402 events, filtered via a `MarketplaceFilter` — verify this filter's compatibility whenever listing/tag shapes change.
- **Receipts**: Arcadestr uses **NIP-102** (`kind:1020`), a Marketplace Receipt standard authored for this project. Key properties a designer/builder needs to know:
  - Order state is tracked via an `o` tag (order UUID)
  - Content is NIP-44 encrypted (private between buyer/seller)
  - Payment proof is dual **BOLT-11 invoice + preimage**
  - Status updates form an **append-only chain** via `e`-tag references (each new status event references the prior one — think of it as an immutable order timeline, not an editable record)
  - Includes a **verified buyer review** mechanism tied to a completed, proven purchase

## Payment direction (in progress, not yet built)
Payment flow design is being informed by Shopstr's Lightning/Cashu architecture, extended with NIP-102's dual-proof design. There's also exploratory thinking about adapting Monero's subaddress derivation model to secp256k1 for per-order, per-merchant payment addresses — this is a candidate direction, not committed. A design/implementation handoff should treat "checkout" as: generate order → generate BOLT-11 invoice (possibly per-order subaddress-style) → buyer pays → preimage becomes proof → NIP-102 receipt chain updates.

## Planned AI-assisted features (design/prompt stage only)
Two features have prompt-engineering work done but are not built:
1. **Portable gamertag identity** — NIP-49/NIP-05 based, so a user's identity/reputation travels with them across relays
2. **NIP-58 achievement badge display** — showing earned badges on profile/listings
Both are planned around a strict "gate-and-approve" agent workflow (AI proposes, human confirms before anything is committed/published) — this pattern should carry through to any UI for these features: nothing auto-publishes without explicit user confirmation.

## Known state / open items for whoever picks this up
- NIP-15 → NIP-99 migration is **complete**, including resolving the two-struct tag alignment
- `MarketplaceFilter` compatibility post-migration was being actively verified
- Payment architecture is **exploratory** — no committed implementation yet
- Dev environment: Manjaro Linux, AMD RX 5600 XT (relevant only if native rendering/GPU issues come up)
