# Arcadestr — Design Spec (Handoff)

Desktop app (Tauri + Leptos), so design for a native-feeling desktop window, not a responsive web page — fixed-ish chrome, keyboard shortcuts welcome, no mobile breakpoints needed.

## App-level structure
Primary surfaces the design should cover:
1. **Browse / Discovery** — listing feed
2. **Listing detail** — single item view
3. **Checkout / Payment** — Lightning invoice flow
4. **Order status** — receipt/order timeline
5. **Profile** — identity, badges, reviews
6. **Publish/manage listing** (seller side)

## 1. Browse / Discovery
- Feed of NIP-99 listings pulled live from Nostr relays — design should account for **loading, partial-results (some relays slow/dead), and empty states**, since relay-based discovery isn't instant or guaranteed complete.
- Filter/search affordances (by category, price, seller) map to `MarketplaceFilter` on the backend — keep filters to things that filter maps support, don't invent filter dimensions the protocol can't express yet.
- Each listing card: title, price, seller identity (with portable gamertag identity when available), thumbnail if present.

## 2. Listing detail
- Full listing content, seller info, and — if the seller has them — **NIP-58 achievement badges** displayed on their profile/listing context.
- Seller reputation surfaced via **verified buyer reviews** (NIP-102) — design should distinguish "verified" (tied to a real completed purchase) from any unverified feedback, since verification is a core trust feature of the protocol.
- Primary action: **Buy** → enters checkout.

## 3. Checkout / Payment
- Order creation generates an order UUID and a **BOLT-11 Lightning invoice**.
- States to design explicitly:
  - Invoice generated, awaiting payment (likely a QR code + copyable invoice string, standard Lightning UX)
  - Payment detected / preimage received (proof captured)
  - Payment failed / invoice expired
- This is a **peer-to-peer, non-custodial** flow — no "cart," no centralized checkout aggregation. Keep language honest about that (e.g., "Waiting for payment" not "Processing order").

## 4. Order status (receipt timeline)
- Because NIP-102 receipts are an **append-only chain of status events**, this screen should read as an immutable timeline/log, not an editable order record — think shipment tracker, not editable form.
- Statuses to support at minimum: order created → payment confirmed → (seller) fulfilled/shipped → completed → (optional) review left.
- Each step is a discrete, timestamped, chained event — the UI can show them as a vertical timeline.

## 5. Profile
- Identity display: supports **portable gamertag identity** (NIP-49/NIP-05) — i.e. an identity that isn't locked to a single relay/app.
- Badge case: **NIP-58 achievement badges**, user-curated (which badges to display).
- Review history (as seller and/or buyer), all verified-purchase-linked.
- **AI-assisted identity/badge features use a gate-and-approve pattern** — if the design includes any AI-suggested profile content (e.g. suggested badges to feature), it must show a clear proposal state the user explicitly approves before anything publishes. Never auto-publish.

## 6. Publish / manage listing (seller side)
- Form for creating a NIP-99 listing: title, description, price, category, images.
- Seller's own listings dashboard: active, sold, draft.
- Editing a live listing should be honest about Nostr semantics — an "edit" typically means republishing a replaceable event, not mutating history in place.

## Cross-cutting notes for the design system
- **Trust and verification are the core visual language** of this product — verified reviews, proof-of-payment, chained receipts. Wherever the design can visually distinguish "verified/proven" from "claimed/unverified," it should.
- **Nothing is instant** — relay propagation, invoice payment, and confirmation all have latency. Design loading/pending states as first-class, not afterthoughts.
- No committed visual identity yet (palette/type/etc.) — that's open for Claude Design to propose as part of the build, grounded in the marketplace/trust/Lightning subject matter above.
